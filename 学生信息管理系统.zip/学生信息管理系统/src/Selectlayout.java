import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.awt.Color;
import java.sql.*;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class Selectlayout extends JFrame{
	private static JLabel jl_1;//����
	private static JFrame jf_1;//���
	private static JLabel jl_string;//��ʾ��Ϣ
	//���µĶ�Ӧ������ʾ��Ϣ�ַ���
	private static JLabel jl_student;
	private static JLabel jl_student_all;
	private static JLabel jl_class;
	private static JLabel jl_class_all;
	private static JLabel jl_major_all;
	private static JLabel jl_department_all;
	private static JLabel jl_association_all;
	private static JLabel jl_SA_all;
	//���¶�Ӧ��ν�İ�ť
	private static JButton jl_student_button;
	private static JButton jl_student_all_button;
	private static JButton jl_class_button;
	private static JButton jl_class_all_button;
	private static JButton jl_major_all_button;
	private static JButton jl_department_all_button;
	private static JButton jl_association_all_button;
	private static JButton jl_SA_all_button;
	public Selectlayout(){
		Font font =new Font("����", Font.PLAIN, 20);//��������
	    jf_1=new JFrame("ִ�в�������ѯ");
		jf_1.setSize(500, 600);
		jf_1.setLocationRelativeTo(null);  
		jl_1 = new JLabel();
		
		jl_string = new JLabel("��ѡ��������Ҫ�Ĳ�����");
		jl_string.setBounds(20,50,300,50);
		jl_string.setFont(font);
		jl_string.setForeground(Color.BLUE);
		
		
		jl_student  = new JLabel("����ѧ�Ų�ѯѧ����Ϣ");
		jl_student.setFont(font);
		jl_student.setBounds(20,100,300,50);
		
		jl_student_button = new JButton("��ѯ");
		jl_student_button.setBounds(300,100,100,50);
		jl_student_button.setFont(font);
		
		jl_student_all  = new JLabel("��ѯ����ѧ����Ϣ");
		jl_student_all.setFont(font);
		jl_student_all.setBounds(20,150,300,50);
		
		jl_student_all_button = new JButton("��ѯ");
		jl_student_all_button.setBounds(300,150,100,50);
		jl_student_all_button.setFont(font);
		
		jl_class  = new JLabel("���ݰ�Ų�ѯ�༶��Ϣ");
		jl_class.setFont(font);
		jl_class.setBounds(20,200,300,50);
		
		jl_class_button = new JButton("��ѯ");
		jl_class_button.setBounds(300,200,100,50);
		jl_class_button.setFont(font);
		
		jl_class_all  = new JLabel("��ѯ���а༶��Ϣ");
		jl_class_all.setFont(font);
		jl_class_all.setBounds(20,250,300,50);
		
		jl_class_all_button = new JButton("��ѯ");
		jl_class_all_button.setBounds(300,250,100,50);
		jl_class_all_button.setFont(font);
		
		jl_major_all  = new JLabel("��ѯ����רҵ��Ϣ");
		jl_major_all.setFont(font);
		jl_major_all.setBounds(20,300,300,50);
		
		jl_major_all_button = new JButton("��ѯ");
		jl_major_all_button.setBounds(300,300,100,50);
		jl_major_all_button.setFont(font);
		
		jl_department_all  = new JLabel("��ѯ����Ժϵ��Ϣ");
		jl_department_all.setFont(font);
		jl_department_all.setBounds(20,350,300,50);
		
		jl_department_all_button = new JButton("��ѯ");
		jl_department_all_button.setBounds(300,350,100,50);
		jl_department_all_button.setFont(font);
		
		jl_association_all  = new JLabel("��ѯ����ѧ����Ϣ");
		jl_association_all.setFont(font);
		jl_association_all.setBounds(20,400,300,50);
		
		jl_association_all_button = new JButton("��ѯ");
		jl_association_all_button.setBounds(300,400,100,50);
		jl_association_all_button.setFont(font);
		
		jl_SA_all = new JLabel("����ѧ��ѡ���ѧ��");
		jl_SA_all.setFont(font);
		jl_SA_all.setBounds(20,450,300,50);
		jl_SA_all_button = new JButton("��ѯ");
		jl_SA_all_button.setBounds(300,450,100,50);
		jl_SA_all_button.setFont(font);
		
		
		jl_1.add(jl_association_all);
		jl_1.add(jl_association_all_button);
		jl_1.add(jl_class);
		jl_1.add(jl_class_all);
		jl_1.add(jl_class_button);
		jl_1.add(jl_department_all);
		jl_1.add(jl_class_all_button);
		jl_1.add(jl_department_all_button);
		jl_1.add(jl_string);
		jl_1.add(jl_major_all);
		jl_1.add(jl_major_all_button);
		jl_1.add(jl_student);
		jl_1.add(jl_student_all);
		jl_1.add(jl_student_all_button);
		jl_1.add(jl_student_button);
		jl_1.add(jl_SA_all);
		jl_1.add(jl_SA_all_button);
		jf_1.add(jl_1);
		jf_1.setVisible(true);
		
		ActionListener jl_department_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Select_Department_all_view S = new Select_Department_all_view();
				
			}
		};
		jl_department_all_button.addActionListener(jl_department_all_button_listener);
		
		
		ActionListener jl_class_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Select_class_all_view S = new Select_class_all_view();
				
			}
		};
		jl_class_all_button.addActionListener(jl_class_all_button_listener);
		
		
		
		ActionListener jl_student_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Select_student_all_view S = new Select_student_all_view();
				
			}
		};
		jl_student_all_button.addActionListener(jl_student_all_button_listener);
		
		
		ActionListener jl_major_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Select_major_all_view S = new Select_major_all_view();
				
			}
		};
		jl_major_all_button.addActionListener(jl_major_all_button_listener);
		
		ActionListener jl_association_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Select_association_all_view S = new Select_association_all_view();
				
			}
		};
		jl_association_all_button.addActionListener(jl_association_all_button_listener);
		
		ActionListener jl_SA_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Select_SA_all_view S = new Select_SA_all_view();
				
			}
		};
		jl_SA_all_button.addActionListener(jl_SA_all_button_listener);
		
		ActionListener jl_student_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Select_student_view S = new Select_student_view();
				
			}
		};
		jl_student_button.addActionListener(jl_student_button_listener);
		
		
		ActionListener jl_class_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Select_class_view S = new Select_class_view();
				
			}
		};
		jl_class_button.addActionListener(jl_class_button_listener);
	}
}
