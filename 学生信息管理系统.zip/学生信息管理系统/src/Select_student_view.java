import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Select_student_view extends JFrame{
	private static JLabel jl_0;
	Font font =new Font("����", Font.PLAIN, 20);//��������
	private static JLabel jl_1;
	private static JButton bt1;//��ѯ��ť
	private static JFrame jf_1;//��½�Ŀ��
    private static JTextField jtext1;//����
    public Select_student_view()
    {
    	jf_1=new JFrame("��ѧ�Ų�ѯѧ��");
 		jf_1.setSize(300, 400);
 		jf_1.setLocationRelativeTo(null);  
 		
 		jl_1=new JLabel();
 		
 		jl_0 = new JLabel("������ѧ��ѧ�ţ�");
		jl_0.setBounds(20,50,300,50);
		jl_0.setFont(font);
		jl_0.setForeground(Color.BLUE);
		
		bt1=new JButton("��ѯ");         //���ĳ�loginButton
		bt1.setBounds(90, 200, 100, 50);
		bt1.setFont(font);
		
		jtext1=new JTextField("");
		jtext1.setBounds(20, 100, 250, 50);
		jtext1.setFont(font); 
		
		jl_1.add(bt1);
		jl_1.add(jl_0);
		jl_1.add(jtext1);
		
		jf_1.add(jl_1);
		
		ActionListener bt1_ls=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String SSno=jtext1.getText();
				String url = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=StudentInformation;";
				String user = "sa";
		        String password = "123456";
		        Connection conn;
			    Statement stmt;
			    String sql = "select * from StudentView where Sno="+SSno;
			    ResultSet rs;
		        try {
		            // �������ݿ�
		            conn = DriverManager.getConnection(url, user, password);
		            // ����Statement����
		            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		            // ִ�����ݿ��ѯ���
		            rs = stmt.executeQuery(sql);
		            rs.last();
		            int rows = rs.getRow();
		            int i=0;
		            rs.beforeFirst();
		            System.out.println(rows);
		            if(rows==0)
		            {
		            	JOptionPane.showMessageDialog(null, "ѧ�Ų����ڣ�", "��Ϣ", JOptionPane.WARNING_MESSAGE);
		            }
		            else
		            {
		            	rs.next();
		            	int Sno = rs.getInt(1);
		            	String SSSno = String.valueOf(Sno);
		            	String Sname = rs.getString(2);
		            	int Sage = rs.getInt(3);
		            	String SSage = String.valueOf(Sage);
		            	String Ssex = rs.getString(4);
		            	String Dname= rs.getString("Dname");
		                int Cno = rs.getInt("Cno");
		                String SCno = String.valueOf(Cno);
		                int Ddorm = rs.getInt("Ddorm");
		                String SDdorm = String.valueOf(Ddorm);
		                String FinalString = "ѧ��:"+SSSno+"\n"
		                		        +"����:"+Sname+"\n"
		                		        +"����:"+SSage+"\n"
		                		        +"�Ա�:"+Ssex+"\n"
		                		        +"ϵ��:"+Dname+"\n"
		                		        +"���:"+SCno+"\n"
		                		        +"����:"+SDdorm;
		                JOptionPane.showMessageDialog(null,FinalString, "���", JOptionPane.PLAIN_MESSAGE);
		                rs.close();
				        stmt.close();
				        conn.close();
		            }
		        }
		        catch (SQLException ee) {
					JOptionPane.showMessageDialog(null, "���ݿ�����ʧ��", "��Ϣ", JOptionPane.WARNING_MESSAGE);
		        }
		       
			}
		};
        bt1.addActionListener(bt1_ls);
        jf_1.setVisible(true);
    }
}
