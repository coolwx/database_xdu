import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Insert_class_all_view extends JFrame{
	private static JButton bt1;//���밴ť
	private static JLabel jl_1;//����İ���
	private static JFrame jf_1;//���
    
	private static JTextField jtext_Cpeople;
    private static JTextField jtext_Mno;
    private static JTextField jtext_Cyear;
    private static JTextField jtext_Cno;
    
    private static JLabel jlabel_Mno;
    private static JLabel jlabel_Cpeople;
    private static JLabel jlabel_Cyear;
    private static JLabel jlabel_Cno;
    
    public Insert_class_all_view()
    {
    	Font font =new Font("����", Font.PLAIN, 20);//��������
    	jf_1 =new JFrame("����༶����Ϣ");
    	jf_1.setSize(500, 600);
		jf_1.setLocationRelativeTo(null);  
		jl_1 = new JLabel();
		
		jlabel_Cno = new JLabel("���");
		jlabel_Cno.setFont(font);
		jlabel_Cno.setBounds(20,50,200,50);
		
		jlabel_Mno = new JLabel("רҵ��");
		jlabel_Mno.setFont(font);
		jlabel_Mno.setBounds(20,100,200,50);
		
		jlabel_Cyear = new JLabel("��ѧ���");
		jlabel_Cyear.setFont(font);
		jlabel_Cyear.setBounds(20,150,200,50);
		
		jlabel_Cpeople = new JLabel("����");
		jlabel_Cpeople.setFont(font);
		jlabel_Cpeople.setBounds(20,200,200,50);
		
		jtext_Cno = new JTextField();
		jtext_Cno.setFont(font);
		jtext_Cno.setBounds(200,50,200,50);
		
		jtext_Mno = new JTextField();
		jtext_Mno.setFont(font);
		jtext_Mno.setBounds(200,100,200,50);
		
		jtext_Cyear = new JTextField();
		jtext_Cyear.setFont(font);
		jtext_Cyear.setBounds(200,150,200,50);
		
		
		jtext_Cpeople = new JTextField();
		jtext_Cpeople.setFont(font);
		jtext_Cpeople.setBounds(200,200,200,50);
		
		bt1 = new JButton("����");
		bt1.setFont(font);
		bt1.setBounds(250,400,200,50);
		
		jl_1.add(bt1);
		jl_1.add(jlabel_Cno);
		jl_1.add(jtext_Cno);
		jl_1.add(jlabel_Mno);
		jl_1.add(jlabel_Cpeople);
		jl_1.add(jlabel_Cyear);
		jl_1.add(jtext_Cpeople);
		jl_1.add(jtext_Cyear);
		jl_1.add(jtext_Mno);
		jf_1.add(jl_1);
		jf_1.setVisible(true);
		
		ActionListener bt2_ls=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String Cno=jtext_Cno.getText();
				String Mno = jtext_Mno.getText();
				String Cpeople = jtext_Cpeople.getText();				
                String Cyear = jtext_Cyear.getText();
				String url = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=StudentInformation;";
				String user = "sa";
		        String password = "123456";
		        Connection conn;
			    Statement stmt;
			    ResultSet rs;
			    String sql = "insert into Class values("
			    		+Cno+","
			    		+Mno+","
			    		+Cyear+","
			    		+Cpeople+")";
			    System.out.println(sql);
			    try {
		            // �������ݿ�
		            conn = DriverManager.getConnection(url, user, password);
		            // ����Statement����
		            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		            // ִ�����ݿ��ѯ���
		            int i = stmt.executeUpdate(sql);
		            if(i==1)
		            {
		            	JOptionPane.showMessageDialog(null, "����ɹ�", "��Ϣ", JOptionPane.PLAIN_MESSAGE);
		            }
		            else
		            {
		            	JOptionPane.showMessageDialog(null, "����ʧ�ܣ������������", "��Ϣ", JOptionPane.WARNING_MESSAGE);
		            }
			    }
			    catch (SQLException ee) {
					JOptionPane.showMessageDialog(null, "����ʧ�ܣ������������", "��Ϣ", JOptionPane.WARNING_MESSAGE);
		        }  
			}
		};
        bt1.addActionListener(bt2_ls);	
    }
    
}
