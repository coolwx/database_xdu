import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Insertlayout extends JFrame {
	private static JLabel jl_1;//����
	private static JFrame jf_1;//���
	private static JLabel jl_string;//��ʾ��Ϣ
	//���µĶ�Ӧ������ʾ��Ϣ�ַ���
	private static JLabel jl_student_all;
	private static JLabel jl_class_all;
	private static JLabel jl_major_all;
	private static JLabel jl_department_all;
	private static JLabel jl_association_all;
	private static JLabel jl_SA_all;
	//���¶�Ӧ��ν�İ�ť
	private static JButton jl_student_all_button;
	private static JButton jl_class_all_button;
	private static JButton jl_major_all_button;
	private static JButton jl_department_all_button;
	private static JButton jl_association_all_button;
	private static JButton jl_SA_all_button;
	public Insertlayout(){
		Font font =new Font("����", Font.PLAIN, 20);//��������
	    jf_1=new JFrame("ִ�в���������");
		jf_1.setSize(500, 600);
		jf_1.setLocationRelativeTo(null);  
		jl_1 = new JLabel();
		
		jl_string = new JLabel("��ѡ��������Ҫ�Ĳ�����");
		jl_string.setBounds(20,50,300,50);
		jl_string.setFont(font);
		jl_string.setForeground(Color.BLUE);
		
		
	
		jl_student_all  = new JLabel("����ѧ����Ϣ");
		jl_student_all.setFont(font);
		jl_student_all.setBounds(20,200,300,50);
		
		jl_student_all_button = new JButton("����");
		jl_student_all_button.setBounds(300,200,100,50);
		jl_student_all_button.setFont(font);
		
		
		jl_class_all  = new JLabel("����༶��Ϣ");
		jl_class_all.setFont(font);
		jl_class_all.setBounds(20,250,300,50);
		
		jl_class_all_button = new JButton("����");
		jl_class_all_button.setBounds(300,250,100,50);
		jl_class_all_button.setFont(font);
		
		jl_major_all  = new JLabel("����רҵ��Ϣ");
		jl_major_all.setFont(font);
		jl_major_all.setBounds(20,300,300,50);
		
		jl_major_all_button = new JButton("����");
		jl_major_all_button.setBounds(300,300,100,50);
		jl_major_all_button.setFont(font);
		
		jl_department_all  = new JLabel("����Ժϵ��Ϣ");
		jl_department_all.setFont(font);
		jl_department_all.setBounds(20,350,300,50);
		
		jl_department_all_button = new JButton("����");
		jl_department_all_button.setBounds(300,350,100,50);
		jl_department_all_button.setFont(font);
		
		jl_association_all  = new JLabel("����ѧ����Ϣ");
		jl_association_all.setFont(font);
		jl_association_all.setBounds(20,400,300,50);
		
		jl_association_all_button = new JButton("����");
		jl_association_all_button.setBounds(300,400,100,50);
		jl_association_all_button.setFont(font);
		
		jl_SA_all = new JLabel("����ѧ��ѡ��ѧ����Ϣ");
		jl_SA_all.setFont(font);
		jl_SA_all.setBounds(20,450,300,50);
		jl_SA_all_button = new JButton("����");
		jl_SA_all_button.setBounds(300,450,100,50);
		jl_SA_all_button.setFont(font);
		
		
		jl_1.add(jl_association_all);
		jl_1.add(jl_association_all_button);
		
		jl_1.add(jl_class_all);
		
		jl_1.add(jl_department_all);
		jl_1.add(jl_class_all_button);
		jl_1.add(jl_department_all_button);
		jl_1.add(jl_string);
		jl_1.add(jl_major_all);
		jl_1.add(jl_major_all_button);
		
		jl_1.add(jl_student_all);
		jl_1.add(jl_student_all_button);
		
		jl_1.add(jl_SA_all);
		jl_1.add(jl_SA_all_button);
		jf_1.add(jl_1);
		jf_1.setVisible(true);
		
		ActionListener jl_student_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Insert_student_view S = new Insert_student_view();
				
			}
		};
		jl_student_all_button.addActionListener(jl_student_all_button_listener);
		
		
		
		ActionListener jl_class_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Insert_class_all_view S = new Insert_class_all_view();
				
			}
		};
		jl_class_all_button.addActionListener(jl_class_all_button_listener);
		
		ActionListener jl_major_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Insert_major_all_view S = new Insert_major_all_view();
				
			}
		};
		jl_major_all_button.addActionListener(jl_major_all_button_listener);
		
		ActionListener jl_department_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Insert_all_department_view S = new Insert_all_department_view();
				
			}
		};
		jl_department_all_button.addActionListener(jl_department_all_button_listener);
		

		ActionListener jl_association_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Insert_association_all_view S = new Insert_association_all_view();
				
			}
		};
		jl_association_all_button.addActionListener(jl_association_all_button_listener);
		
		ActionListener jl_SA_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Insert_SA_all_view S = new Insert_SA_all_view();
				
			}
		};
		jl_SA_all_button.addActionListener(jl_SA_all_button_listener);
}
}
