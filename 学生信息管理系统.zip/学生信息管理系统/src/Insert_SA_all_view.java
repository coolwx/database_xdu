import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Insert_SA_all_view extends JFrame{
	private static JButton bt1;//���밴ť
	private static JLabel jl_1;//����İ���
	private static JFrame jf_1;//���
    
	
    private static JTextField jtext_Mno;
    private static JTextField jtext_Mname;
    private static JTextField jtext_Dno;
    
    private static JLabel jlabel_Mno;
    private static JLabel jlabel_Mname;
    private static JLabel jlabel_Dno;
    
    public Insert_SA_all_view()
    {
    	Font font =new Font("����", Font.PLAIN, 20);//��������
    	jf_1 =new JFrame("ѧ��ѡ��ѧ��");
    	jf_1.setSize(500, 600);
		jf_1.setLocationRelativeTo(null);  
		jl_1 = new JLabel();
		
		jlabel_Mno = new JLabel("ѧ��");
		jlabel_Mno.setFont(font);
		jlabel_Mno.setBounds(20,100,200,50);
		
		jlabel_Mname = new JLabel("���ʱ��");
		jlabel_Mname.setFont(font);
		jlabel_Mname.setBounds(20,150,200,50);
		
		jlabel_Dno = new JLabel("ѧ���");
		jlabel_Dno.setFont(font);
		jlabel_Dno.setBounds(20,200,200,50);
		
		
		jtext_Mno = new JTextField();
		jtext_Mno.setFont(font);
		jtext_Mno.setBounds(200,100,200,50);
		
		jtext_Mname = new JTextField();
		jtext_Mname.setFont(font);
		jtext_Mname.setBounds(200,150,200,50);
		
		
		jtext_Dno = new JTextField();
		jtext_Dno.setFont(font);
		jtext_Dno.setBounds(200,200,200,50);
		
		bt1 = new JButton("����");
		bt1.setFont(font);
		bt1.setBounds(250,400,200,50);
		
		jl_1.add(bt1);
		jl_1.add(jlabel_Mno);
		jl_1.add(jtext_Dno);
		jl_1.add(jlabel_Mname);
		jl_1.add(jlabel_Dno);
		jl_1.add(jtext_Mname);
		jl_1.add(jtext_Mno);
		jf_1.add(jl_1);
		jf_1.setVisible(true);
		
		ActionListener bt2_ls=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String Dno=jtext_Dno.getText();
				String Mno = jtext_Mno.getText();
						
                String Mname = jtext_Mname.getText();
				String url = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=StudentInformation;";
				String user = "sa";
		        String password = "123456";
		        Connection conn;
			    Statement stmt;
			    ResultSet rs;
			    String sql = "insert into SA values("
			    		+Mno+","
			    		+Dno+","
			    		+Mname+")";
			    System.out.println(sql);
			    try {
		            // �������ݿ�
		            conn = DriverManager.getConnection(url, user, password);
		            // ����Statement����
		            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		            // ִ�����ݿ��ѯ���
		            int i = stmt.executeUpdate(sql);
		            if(i==1)
		            {
		            	JOptionPane.showMessageDialog(null, "����ɹ�", "��Ϣ", JOptionPane.PLAIN_MESSAGE);
		            }
		            else
		            {
		            	JOptionPane.showMessageDialog(null, "����ʧ�ܣ������������", "��Ϣ", JOptionPane.WARNING_MESSAGE);
		            }
		            stmt.close();
		            conn.close();
			    }
			    catch (SQLException ee) {
					JOptionPane.showMessageDialog(null, "����ʧ�ܣ������������", "��Ϣ", JOptionPane.WARNING_MESSAGE);
		        }  
			}
		};
        bt1.addActionListener(bt2_ls);	
    }
    
}
