import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Update_Procedure_Cno extends JFrame{
	private static JLabel jl_0;
	private static JLabel jl_2;
	Font font =new Font("����", Font.PLAIN, 20);//��������
	private static JLabel jl_1;
	private static JButton bt1;//��ѯ��ť
	private static JFrame jf_1;//��½�Ŀ��
    private static JTextField jtext1;//����ԭ���༶�İ��
    private static JTextField jtext2;//��������༶�İ��
    public Update_Procedure_Cno()
    {
    	jf_1=new JFrame("�������а��");
 		jf_1.setSize(300, 400);
 		jf_1.setLocationRelativeTo(null);  
 		
 		jl_1=new JLabel();
 		
 		jl_0 = new JLabel("ԭ���༶�İ�ţ�");
		jl_0.setBounds(20,50,300,50);
		jl_0.setFont(font);
		jl_0.setForeground(Color.BLUE);
		
		jl_2 = new JLabel("���°༶�İ�ţ�");
		jl_2.setBounds(20,150,300,50);
		jl_2.setFont(font);
		jl_2.setForeground(Color.BLUE);
		
		bt1=new JButton("����");         //���ĳ�loginButton
		bt1.setBounds(90, 300, 100, 50);
		bt1.setFont(font);
		
		jtext1=new JTextField("");
		jtext1.setBounds(20, 100, 250, 50);
		jtext1.setFont(font); 
		
		jtext2=new JTextField("");
		jtext2.setBounds(20, 200, 250, 50);
		jtext2.setFont(font); 
		
		jl_1.add(bt1);
		jl_1.add(jl_0);
		jl_1.add(jtext1);
		jl_1.add(jl_2);
		jl_1.add(jtext2);
		
		jf_1.add(jl_1);
		
		ActionListener bt1_ls=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String SCno=jtext1.getText();
				int Origin = Integer.valueOf(SCno);
				String NCno=jtext2.getText();
				int current = Integer.valueOf(NCno);
				String url = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=StudentInformation;";
				String user = "sa";
		        String password = "123456";
		        Connection conn;
		        CallableStatement  stmt;
			    
		        try {
		            // �������ݿ�
		            conn = DriverManager.getConnection(url, user, password);
		            // ����Statement����
		            stmt = conn.prepareCall("{?=CALL update_Cno(?,?)}");
		             
		            // ִ�����ݿ��ѯ���
		            stmt.registerOutParameter(1,java.sql.Types.INTEGER);
		            stmt.setInt(2, Origin);
		            stmt.setInt(3, current);
		            //�޿ӣ�returnֵ��Ϊ��һ��output��������������������2��3����ľ޿��ޱ�
		            stmt.execute();
		            System.out.println(Origin);
		            Integer people = stmt.getInt(1);
		            String Cpeople = people.toString();
		            String FinalString = "���ĳɹ���ԭ�༶����һ��"+Cpeople+"��";
		            JOptionPane.showMessageDialog(null,FinalString, "���", JOptionPane.PLAIN_MESSAGE);
		            
				   stmt.close();
				   conn.close();
		      
		        }
		        catch (SQLException ee) {
					JOptionPane.showMessageDialog(null, "���벻���ڣ�", "��Ϣ", JOptionPane.WARNING_MESSAGE);
		        }
		       
			}
		};
        bt1.addActionListener(bt1_ls);
        jf_1.setVisible(true);
    }
}
