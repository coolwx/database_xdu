import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Deletlayout {
	private static JLabel jl_1;//����
	private static JFrame jf_1;//���
	private static JLabel jl_string;//��ʾ��Ϣ
	//���µĶ�Ӧ������ʾ��Ϣ�ַ���
	private static JLabel jl_student_all;
	private static JLabel jl_class_all;
	private static JLabel jl_major_all;
	private static JLabel jl_department_all;
	private static JLabel jl_association_all;
	private static JLabel jl_SA_all;
	//���¶�Ӧ��ν�İ�ť
	private static JButton jl_student_all_button;
	private static JButton jl_class_all_button;
	private static JButton jl_major_all_button;
	private static JButton jl_department_all_button;
	private static JButton jl_association_all_button;
	private static JButton jl_SA_all_button;
	public Deletlayout(){
		Font font =new Font("����", Font.PLAIN, 20);//��������
	    jf_1=new JFrame("ִ�в�����ɾ��");
		jf_1.setSize(500, 600);
		jf_1.setLocationRelativeTo(null);  
		jl_1 = new JLabel();
		
		jl_string = new JLabel("��ѡ��������Ҫ�Ĳ�����");
		jl_string.setBounds(20,50,300,50);
		jl_string.setFont(font);
		jl_string.setForeground(Color.BLUE);
		
		
	
		jl_student_all  = new JLabel("ɾ��ѧ����Ϣ");
		jl_student_all.setFont(font);
		jl_student_all.setBounds(20,200,300,50);
		
		jl_student_all_button = new JButton("ɾ��");
		jl_student_all_button.setBounds(300,200,100,50);
		jl_student_all_button.setFont(font);
		
		
		jl_class_all  = new JLabel("ɾ���༶��Ϣ");
		jl_class_all.setFont(font);
		jl_class_all.setBounds(20,250,300,50);
		
		jl_class_all_button = new JButton("ɾ��");
		jl_class_all_button.setBounds(300,250,100,50);
		jl_class_all_button.setFont(font);
		
		jl_major_all  = new JLabel("ɾ��רҵ��Ϣ");
		jl_major_all.setFont(font);
		jl_major_all.setBounds(20,300,300,50);
		
		jl_major_all_button = new JButton("ɾ��");
		jl_major_all_button.setBounds(300,300,100,50);
		jl_major_all_button.setFont(font);
		
		jl_department_all  = new JLabel("ɾ��Ժϵ��Ϣ");
		jl_department_all.setFont(font);
		jl_department_all.setBounds(20,350,300,50);
		
		jl_department_all_button = new JButton("ɾ��");
		jl_department_all_button.setBounds(300,350,100,50);
		jl_department_all_button.setFont(font);
		
		jl_association_all  = new JLabel("ɾ��ѧ����Ϣ");
		jl_association_all.setFont(font);
		jl_association_all.setBounds(20,400,300,50);
		
		jl_association_all_button = new JButton("ɾ��");
		jl_association_all_button.setBounds(300,400,100,50);
		jl_association_all_button.setFont(font);
		
		jl_SA_all = new JLabel("ɾ��ѧ��ѡ��ѧ��");
		jl_SA_all.setFont(font);
		jl_SA_all.setBounds(20,450,300,50);
		jl_SA_all_button = new JButton("ɾ��");
		jl_SA_all_button.setBounds(300,450,100,50);
		jl_SA_all_button.setFont(font);
		jl_1.add(jl_association_all);
		jl_1.add(jl_association_all_button);
		
		jl_1.add(jl_class_all);
		
		jl_1.add(jl_department_all);
		jl_1.add(jl_class_all_button);
		jl_1.add(jl_department_all_button);
		jl_1.add(jl_string);
		jl_1.add(jl_major_all);
		jl_1.add(jl_major_all_button);
		
		jl_1.add(jl_student_all);
		jl_1.add(jl_student_all_button);
		
		jl_1.add(jl_SA_all);
		jl_1.add(jl_SA_all_button);
		jf_1.add(jl_1);
		jf_1.setVisible(true);
		
		ActionListener jl_student_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Delete_Student_view S = new Delete_Student_view();
				
			}
		};
		jl_student_all_button.addActionListener(jl_student_all_button_listener);
		
		
		ActionListener jl_class_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Delete_class_view S = new Delete_class_view();
				
			}
		};
		jl_class_all_button.addActionListener(jl_class_all_button_listener);
		
		ActionListener jl_major_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Delete_major_view S = new Delete_major_view();
				
			}
		};
		jl_major_all_button.addActionListener(jl_major_all_button_listener);
		
		ActionListener jl_department_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Delete_department_all_view S = new Delete_department_all_view();
				
			}
		};
		jl_department_all_button.addActionListener(jl_department_all_button_listener);
		

		ActionListener jl_association_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Delete_association_view S = new Delete_association_view();
				
			}
		};
		jl_association_all_button.addActionListener(jl_association_all_button_listener);
		
		ActionListener jl_SA_all_button_listener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Delete_SA_all_view S = new Delete_SA_all_view();
				
			}
		};
		jl_SA_all_button.addActionListener(jl_SA_all_button_listener);
}
}

