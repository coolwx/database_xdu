import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.awt.BorderLayout;
import java.awt.Color;
import java.sql.*;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.Container;
public class Delete_class_view extends JFrame{
	private static JFrame jf_1;//���
	JTable table;
	public Delete_class_view()
	{
		jf_1 = new JFrame("ɾ���༶�������Ϣ");
		jf_1.setSize(500,500);
		JButton button;
		//jf_1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 JPanel contentPane=new JPanel();
		 String[] colomname = {"���","רҵ��","��У���","ϵ��","����"};
		 String user = "sa";
	     String password = "123456";
	     Connection conn;
	     Statement stmt;
	     ResultSet rs;
	     String url = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=StudentInformation;";
	     String sql = "select * from ClassView";
	     
		try {
            // �������ݿ�
            conn = DriverManager.getConnection(url, user, password);
            // ����Statement����
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
            // ִ�����ݿ��ѯ���
            rs = stmt.executeQuery(sql);
            rs.last();
            int rows = rs.getRow();
            int i=0;
            Object[][] tableDate=new Object[rows][5];
            System.out.println(rows);
            rs.beforeFirst();
            while (rs.next()) {
                int Cno = rs.getInt("Cno");
                String Mname = rs.getString("Mname");
                int Cyear = rs.getInt("Cyear");
                int Cpeople = rs.getInt("Cpeople");
                String Dname = rs.getString("Dname");
                tableDate[i][0] = Cno;
                tableDate[i][1] = Mname;
                tableDate[i][2] = Cyear;
                tableDate[i][3] = Dname;
                tableDate[i][4] = Cpeople;
                i++;
            }
            table=new JTable(tableDate,colomname);
            table.setModel(new DefaultTableModel(tableDate,colomname));
            contentPane.add(new JScrollPane(table));
            table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            JScrollPane scrollPane=new JScrollPane();
            contentPane.add(scrollPane,BorderLayout.CENTER);
            scrollPane.setViewportView(table);
            rs.close();
            stmt.close();
            conn.close();
            button = new JButton("ɾ��");
   		    button.setBounds(200, 400, 100, 50);
   		    
   		    button.addActionListener(new ActionListener()
   	         {
   		    	
   		    	public void actionPerformed(ActionEvent e)
   		    	{
   	            do_button_actionPerformed(e);
   		    	}
   	         });
 		    contentPane.add(button);
 		    jf_1.add(contentPane);
 		    jf_1.setVisible(true);
		
		
		    jf_1.setVisible(true);
		}
		
		catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "���ݿ�����ʧ��", "��Ϣ", JOptionPane.WARNING_MESSAGE);
        }
		jf_1.setVisible(true);
	}
	
	protected void do_button_actionPerformed(ActionEvent e)
   	{
   	    DefaultTableModel model=(DefaultTableModel) table.getModel();    //��ñ���ģ��
   	    int selectedRows=table.getSelectedRow();
   	    
   	    Object obj = model.getValueAt(selectedRows, 0);
	    int x  = ((Integer)obj).intValue();
	    String Sno = String.valueOf(x);
   	    model.removeRow(selectedRows);
   	    String url = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=StudentInformation;";
		String user = "sa";
        String password = "123456";
        Connection conn;
	    Statement stmt;
	    String sql = "delete from Class where Cno="+Sno;
	    System.out.println(sql);
	    try {
            // �������ݿ�
            conn = DriverManager.getConnection(url, user, password);
            // ����Statement����
            stmt = conn.createStatement();
            int i = stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "ɾ���ɹ�", "��Ϣ", JOptionPane.PLAIN_MESSAGE);
            stmt.close();
            conn.close();
	    }
	    catch(SQLException ee)
	    {
	    	JOptionPane.showMessageDialog(null, "ɾ��ʧ�ܣ����ݿ�����ʧ��", "��Ϣ", JOptionPane.WARNING_MESSAGE);
	    }
   	    table.setModel(model);
   	}
}


