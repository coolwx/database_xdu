import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.awt.Color;
import java.sql.*;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.Container;
public  class Update_Procedure_check_people extends JFrame{
	private static JFrame jf_1;//���
	public  Update_Procedure_check_people()
	{
		jf_1 = new JFrame("ʹ�ô洢���̸�������ϵ������");
		jf_1.setSize(500,500);
		//jf_1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 Container contentPane=jf_1.getContentPane();
		 String[] colomname = {"ϵ��","ϵ��","ԭ������","��������"};
		 String user = "sa";
	     String password = "123456";
	     Connection conn;
	     CallableStatement stmt;
	     Statement stmt2;
	     ResultSet rs;
	     String url = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=StudentInformation;";
		try {
            // �������ݿ�
            conn = DriverManager.getConnection(url, user, password);
            // ����Statement����
            stmt = conn.prepareCall("{call dbo.Check_Dpeople(?,?,?,?)}",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
            
            // ִ�����ݿ��ѯ���
            stmt.setInt(1, 1);
            stmt.setString(2,"С��");
            stmt.setInt(3, 0);
            stmt.setInt(4, 0);
            stmt.execute();
            
            stmt2 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
            rs = stmt2.executeQuery("select * from Procedure_record");
            rs.last();
            int rows = rs.getRow();
            int i=0;
            Object[][] tableDate=new Object[rows][4];
            rs.beforeFirst();
            if(rows == 0)
            {
            	JOptionPane.showMessageDialog(null, "�������ݶ��Ѿ���ȷ", "��Ϣ", JOptionPane.WARNING_MESSAGE);
            }
            while (rs.next()) {
                int Dno = rs.getInt(1);
                String Dname = rs.getString(2);
                int Dpeople = rs.getInt(3);
                int Dnewpeople = rs.getInt(4);
                tableDate[i][0] = Dno;
                tableDate[i][1] = Dname;
                tableDate[i][2] = Dpeople;
                tableDate[i][3] = Dnewpeople;
                
                i++;
            }
            JOptionPane.showMessageDialog(null, "�Ѿ�����˸��Ĳ�����������������", "��Ϣ", JOptionPane.WARNING_MESSAGE);
            JTable table=new JTable(tableDate,colomname);
            contentPane.add(new JScrollPane(table));
            rs.close();
            stmt.close();
            stmt2.close();
            conn.close();
		}
		catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "���ݿ�����ʧ��", "��Ϣ", JOptionPane.WARNING_MESSAGE);
        }
		jf_1.setVisible(true);
	}
}



