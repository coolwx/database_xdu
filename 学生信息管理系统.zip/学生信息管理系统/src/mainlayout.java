import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.awt.Color;
import java.sql.*;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class mainlayout extends JFrame{
	private static JLabel jl_1;//��¼�İ���
	private static JFrame jf_1;//��½�Ŀ��
	private static JLabel jl_string;//��ʾ��Ϣ�ı�ǩ���ַ�����
	private static JLabel jl_statement;//��ʾ״̬��Ϣ
	//private static JLabel jl_warning;//�������ĸ�״̬
	private static JButton bt_insert;//��_��ť
	private static JButton bt_delete;//ɾ_��ť
	private static JButton bt_select;//ѡ��_��ť
	private static JButton bt_update;//����
	public mainlayout(String user,String password)
	{
		
		Connection conn;
		String url = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=StudentInformation;";
		try {
            // �������ݿ�
            conn = DriverManager.getConnection(url, user, password);
            JOptionPane.showMessageDialog(null, "�����Գɹ��������ݿ�!", "��Ϣ", JOptionPane.PLAIN_MESSAGE);
        	conn.close();
		}
		 catch (SQLException e) {
			 JOptionPane.showMessageDialog(null, "���ݿ�����ʧ�ܣ��������ݿ�˿�����", "��Ϣ", JOptionPane.WARNING_MESSAGE);
			 System.exit(0);
	    }
	    Font font =new Font("����", Font.PLAIN, 20);//��������
		jf_1=new JFrame("ѧ����Ϣ����ϵͳ");
		jf_1.setSize(500, 600);
		jf_1.setLocationRelativeTo(null);  
		//����½�������ӱ���ͼƬ
		ImageIcon bgim = new ImageIcon(helloLabel.class.getResource("����.JPG")) ;//����ͼ��
		bgim.setImage(bgim.getImage().
				                     getScaledInstance(bgim.getIconWidth(),
												       bgim.getIconHeight(), 
												       Image.SCALE_DEFAULT));
		jl_1 = new JLabel();
		jl_1.setIcon(bgim);
		
		jl_string = new JLabel("��ѡ��������Ҫ�Ĳ�����");
		jl_string.setBounds(20,50,300,50);
		jl_string.setFont(font);
		jl_string.setForeground(Color.BLUE);
		
		jl_statement = new JLabel("����״̬���Ѿ���¼");
	    jl_statement.setBounds(480,50,300,50);
		jl_statement.setFont(font);
		jl_statement.setForeground(Color.RED);
		
		bt_insert = new JButton("��");
		bt_insert.setFont(font);
		bt_insert.setBounds(90, 100, 100, 50);
		
		
		bt_delete = new JButton("ɾ��");
		bt_delete.setFont(font);
		bt_delete.setBounds(90, 180, 100, 50);
		
		bt_select = new JButton("��ѯ");
		bt_select.setFont(font);
		bt_select.setBounds(90, 260, 100, 50);
		
		bt_update = new JButton("����");
		bt_update.setFont(font);
		bt_update.setBounds(90, 340, 100, 50);
	
		ActionListener bt_select_actionlistener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Selectlayout S = new Selectlayout();
			}
		};
		bt_select.addActionListener(bt_select_actionlistener);
		
		ActionListener bt_insert_actionlistener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Insertlayout S = new Insertlayout();
			}
		};
		bt_insert.addActionListener(bt_insert_actionlistener);
		
		ActionListener bt_delete_actionlistener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Deletlayout S = new Deletlayout();
			}
		};
		bt_delete.addActionListener(bt_delete_actionlistener);
		
		ActionListener bt_update_actionlistener=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Updatelayout S = new Updatelayout();
			}
		};
		bt_update.addActionListener(bt_update_actionlistener);
		
		jl_1.add(jl_statement);
		jl_1.add(jl_string);
		jl_1.add(bt_delete);
		jl_1.add(bt_insert);
		jl_1.add(bt_select);
		jl_1.add(bt_update);
		jf_1.add(jl_1);
		jf_1.setVisible(true);
	}
}
