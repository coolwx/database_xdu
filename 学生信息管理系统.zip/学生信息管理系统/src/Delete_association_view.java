import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.awt.BorderLayout;
import java.awt.Color;
import java.sql.*;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.Container;
public class Delete_association_view extends JFrame{
	private static JFrame jf_1;//���
	JTable table;
	public Delete_association_view()
	{
		jf_1 = new JFrame("ɾ��ѧ��������Ϣ");
		
		jf_1.setSize(500,500);
		JButton button;
		//jf_1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 JPanel contentPane=new JPanel();
		 String[] colomname = {"ѧ���","ѧ����","����ʱ��","�ص�","����"};
		 String user = "sa";
	     String password = "123456";
	     Connection conn;
	     Statement stmt;
	     ResultSet rs;
	     String url = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=StudentInformation;";
	     String sql = "select Association.Ano,Association.Aname,Association.Atime,Association.Aplace,AssociationPeopleView.Apeople from Association,AssociationPeopleView where Association.Aname=AssociationPeopleView.Aname";
		try {
            // �������ݿ�
            conn = DriverManager.getConnection(url, user, password);
            // ����Statement����
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
            // ִ�����ݿ��ѯ���
            rs = stmt.executeQuery(sql);
            rs.last();
            int rows = rs.getRow()+1;
            int i=0;
            //int rows = 4;
            Object[][] tableDate=new Object[rows][5];
            rs.beforeFirst();
            System.out.println(rows);
            while (rs.next()) {
                int Ano = rs.getInt(1);
                String Aname = rs.getString(2);
                Date Atime =rs.getDate(3);
                String Aplace = rs.getString(4);
                int Apeople = rs.getInt(5);
                tableDate[i][0] = Ano;
                tableDate[i][1] = Aname;
                tableDate[i][2] = Atime;
                tableDate[i][3] = Aplace;
                tableDate[i][4] = Apeople;
                i++;
            }
            table=new JTable(tableDate,colomname);
            table.setModel(new DefaultTableModel(tableDate,colomname));
            contentPane.add(new JScrollPane(table));
            table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            JScrollPane scrollPane=new JScrollPane();
            contentPane.add(scrollPane,BorderLayout.CENTER);
            scrollPane.setViewportView(table);
            rs.close();
            stmt.close();
            conn.close();
            button = new JButton("ɾ��");
   		    button.setBounds(200, 400, 100, 50);
   		    
   		    button.addActionListener(new ActionListener()
   	         {
   		    	
   		    	public void actionPerformed(ActionEvent e)
   		    	{
   	            do_button_actionPerformed(e);
   		    	}
   	         });
 		    contentPane.add(button);
 		    jf_1.add(contentPane);
 		    jf_1.setVisible(true);
		
		
		    jf_1.setVisible(true);
		}
		
		catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "���ݿ�����ʧ��", "��Ϣ", JOptionPane.WARNING_MESSAGE);
        }
		jf_1.setVisible(true);
	}
	
	protected void do_button_actionPerformed(ActionEvent e)
   	{
   	    DefaultTableModel model=(DefaultTableModel) table.getModel();    //��ñ���ģ��
   	    int selectedRows=table.getSelectedRow();
   	    
   	    Object obj = model.getValueAt(selectedRows, 0);
	    int x  = ((Integer)obj).intValue();
	    String Sno = String.valueOf(x);
   	    model.removeRow(selectedRows);
   	    String url = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=StudentInformation;";
		String user = "sa";
        String password = "123456";
        Connection conn;
	    Statement stmt;
	    String sql = "delete from Association where Ano="+Sno;
	    System.out.println(sql);
	    try {
            // �������ݿ�
            conn = DriverManager.getConnection(url, user, password);
            // ����Statement����
            stmt = conn.createStatement();
            int i = stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "ɾ���ɹ�", "��Ϣ", JOptionPane.PLAIN_MESSAGE);
            stmt.close();
            conn.close();
	    }
	    catch(SQLException ee)
	    {
	    	JOptionPane.showMessageDialog(null, "ɾ��ʧ�ܣ����ݿ�����ʧ��", "��Ϣ", JOptionPane.WARNING_MESSAGE);
	    }
   	    table.setModel(model);
   	}
}


