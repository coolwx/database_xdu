import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Insert_all_department_view extends JFrame{
	private static JButton bt1;//���밴ť
	private static JLabel jl_1;//����İ���
	private static JFrame jf_1;//���
    
	private static JTextField jtext_Dname;
    private static JTextField jtext_Dno;
    private static JTextField jtext_Dplace;
    private static JTextField jtext_Ddorm;
    
    private static JLabel jlabel_Dno;
    private static JLabel jlabel_Dname;
    private static JLabel jlabel_Ddorm;
    private static JLabel jlabel_Dplace;
    private static JLabel jlabel_Dpeople;
    
    public Insert_all_department_view()
    {
    	Font font =new Font("����", Font.PLAIN, 20);//��������
    	jf_1 =new JFrame("����Ժϵ����Ϣ");
    	jf_1.setSize(500, 600);
		jf_1.setLocationRelativeTo(null);  
		jl_1 = new JLabel();
		
		jlabel_Dno = new JLabel("Ժϵ��");
		jlabel_Dno.setFont(font);
		jlabel_Dno.setBounds(20,50,200,50);
		
		jlabel_Dname = new JLabel("Ժϵ��");
		jlabel_Dname.setFont(font);
		jlabel_Dname.setBounds(20,100,200,50);
		
		jlabel_Dplace = new JLabel("�칫�ҵص�");
		jlabel_Dplace.setFont(font);
		jlabel_Dplace.setBounds(20,150,200,50);
		
		jlabel_Ddorm = new JLabel("������");
		jlabel_Ddorm.setFont(font);
		jlabel_Ddorm.setBounds(20,200,200,50);
		
		jlabel_Dpeople = new JLabel("����ʱԺϵ����Ĭ��Ϊ0");
		jlabel_Dpeople.setFont(font);
		jlabel_Dpeople.setBounds(20,250,300,50);
		
		jtext_Dno = new JTextField();
		jtext_Dno.setFont(font);
		jtext_Dno.setBounds(200,50,200,50);
		
		jtext_Dname = new JTextField();
		jtext_Dname.setFont(font);
		jtext_Dname.setBounds(200,100,200,50);
		
		jtext_Dplace = new JTextField();
		jtext_Dplace.setFont(font);
		jtext_Dplace.setBounds(200,150,200,50);
		
		
		jtext_Ddorm = new JTextField();
		jtext_Ddorm.setFont(font);
		jtext_Ddorm.setBounds(200,200,200,50);
		
		bt1 = new JButton("����");
		bt1.setFont(font);
		bt1.setBounds(250,400,200,50);
		
		jl_1.add(bt1);
		jl_1.add(jlabel_Dno);
		jl_1.add(jtext_Dno);
		jl_1.add(jlabel_Dname);
		jl_1.add(jlabel_Dplace);
		jl_1.add(jlabel_Dpeople);
		jl_1.add(jtext_Ddorm);
		jl_1.add(jtext_Dname);
		jl_1.add(jtext_Dplace);
		jl_1.add(jlabel_Ddorm);
		jf_1.add(jl_1);
		jf_1.setVisible(true);
		
		ActionListener bt2_ls=new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String Dno=jtext_Dno.getText();
				String Dname = jtext_Dname.getText();
				String Dplace = jtext_Dplace.getText();				
                String Ddorm = jtext_Ddorm.getText();
				String url = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=StudentInformation;";
				String user = "sa";
		        String password = "123456";
		        Connection conn;
			    Statement stmt;
			    ResultSet rs;
			    String sql = "insert into Department values("
			    		+Dno+",'"
			    		+Dname+"','"
			    		+Dplace+"',"
			    		+Ddorm+",0)";
			    System.out.println(sql);
			    try {
		            // �������ݿ�
		            conn = DriverManager.getConnection(url, user, password);
		            // ����Statement����
		            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		            // ִ�����ݿ��ѯ���
		            int i = stmt.executeUpdate(sql);
		            if(i==1)
		            {
		            	JOptionPane.showMessageDialog(null, "����ɹ�", "��Ϣ", JOptionPane.PLAIN_MESSAGE);
		            }
		            else
		            {
		            	JOptionPane.showMessageDialog(null, "����ʧ�ܣ������������", "��Ϣ", JOptionPane.WARNING_MESSAGE);
		            }
			    }
			    catch (SQLException ee) {
					JOptionPane.showMessageDialog(null, "����ʧ�ܣ������������", "��Ϣ", JOptionPane.WARNING_MESSAGE);
		        }  
			}
		};
        bt1.addActionListener(bt2_ls);	
    }
    
}
